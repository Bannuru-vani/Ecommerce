// import { ActionTypes } from "../contants/action-types";
// const initialState = {
//   data: [],
// };

// // const initialState = {
// //   products: [
// //     {
// //       id: 1,
// //       name: "vani",
// //     },
// //   ],
// // };

// export const tablereducers = (state = initialState, action) => {
//   const { type, data } = action;

//   //   console.log(data, action, "data");
//   //   console.log(ActionTypes);

//   switch (type) {
//     case ActionTypes.SHOW_DATA:
//       return {
//         ...state,
//         data: data,
//       };

//     default:
//       return state;
//   }
// };
