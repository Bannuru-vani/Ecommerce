// import React, { useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { getProductsData } from "../redux/actions/tableaction";

// function Table() {
//   const data = useSelector((state) => state.tablereducers);
//   console.log(data);
//   const dispatch = useDispatch();
//   useEffect(() => {
//     dispatch(getProductsData());
//   }, []);

//   return <div>table</div>;
// }

// export default Table;
