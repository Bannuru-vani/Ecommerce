import React from "react";

function Allproducts() {
  return <div>Allproducts</div>;
}

export default Allproducts;
